<?php
/**
 * Markas API Endpoints
 * CRUD əməliyyatları markalar üçün
 */

// Get marka ID if provided
$markaId = isset($pathParts[1]) && is_numeric($pathParts[1]) ? (int)$pathParts[1] : null;

switch ($method) {
    case 'GET':
        if ($markaId) {
            getMarka($db, $markaId);
        } else {
            getMarkas($db);
        }
        break;
    case 'POST':
        createMarka($db);
        break;
    case 'PUT':
        if ($markaId) {
            updateMarka($db, $markaId);
        } else {
            errorResponse('Marka ID tələb olunur', 400);
        }
        break;
    case 'DELETE':
        if ($markaId) {
            deleteMarka($db, $markaId);
        } else {
            errorResponse('Marka ID tələb olunur', 400);
        }
        break;
    default:
        errorResponse('Method dəstəklənmir', 405);
}

function getMarkas($db) {
    try {
        $stmt = $db->prepare("SELECT * FROM markas ORDER BY name ASC");
        $stmt->execute();
        $markas = $stmt->fetchAll();
        
        successResponse($markas);
        
    } catch (Exception $e) {
        errorResponse('Server xətası: ' . $e->getMessage(), 500);
    }
}

function getMarka($db, $id) {
    try {
        $stmt = $db->prepare("SELECT * FROM markas WHERE id = ?");
        $stmt->execute([$id]);
        $marka = $stmt->fetch();
        
        if (!$marka) {
            errorResponse('Marka tapılmadı', 404);
        }
        
        successResponse($marka);
        
    } catch (Exception $e) {
        errorResponse('Server xətası: ' . $e->getMessage(), 500);
    }
}

function createMarka($db) {
    $user = authenticateToken();
    
    $name = $_POST['name'] ?? null;
    $description = $_POST['description'] ?? null;
    $website = $_POST['website'] ?? null;
    
    if (!$name) {
        errorResponse('Marka adı tələb olunur');
    }
    
    // Handle file upload
    $logoPath = null;
    if (isset($_FILES['logoFile'])) {
        $logoPath = handleFileUpload('logoFile', 'uploads');
    }
    
    try {
        // Check if marka already exists
        $stmt = $db->prepare("SELECT id FROM markas WHERE name = ?");
        $stmt->execute([$name]);
        if ($stmt->fetch()) {
            errorResponse('Bu adda marka artıq mövcuddur');
        }
        
        $stmt = $db->prepare("
            INSERT INTO markas (name, description, logo, website) 
            VALUES (?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $name,
            $description,
            $logoPath,
            $website
        ]);
        
        $markaId = $db->lastInsertId();
        
        // Get the created marka
        $stmt = $db->prepare("SELECT * FROM markas WHERE id = ?");
        $stmt->execute([$markaId]);
        $marka = $stmt->fetch();
        
        successResponse($marka, 'Marka yaradıldı');
        
    } catch (Exception $e) {
        errorResponse('Server xətası: ' . $e->getMessage(), 500);
    }
}

function updateMarka($db, $id) {
    $user = authenticateToken();
    
    $name = $_POST['name'] ?? null;
    $description = $_POST['description'] ?? null;
    $website = $_POST['website'] ?? null;
    
    if (!$name) {
        errorResponse('Marka adı tələb olunur');
    }
    
    try {
        // Check if marka exists
        $stmt = $db->prepare("SELECT * FROM markas WHERE id = ?");
        $stmt->execute([$id]);
        $existingMarka = $stmt->fetch();
        
        if (!$existingMarka) {
            errorResponse('Marka tapılmadı', 404);
        }
        
        // Check if name is already taken by another marka
        $stmt = $db->prepare("SELECT id FROM markas WHERE name = ? AND id != ?");
        $stmt->execute([$name, $id]);
        if ($stmt->fetch()) {
            errorResponse('Bu adda marka artıq mövcuddur');
        }
        
        // Handle file upload
        $logoPath = $existingMarka['logo'];
        if (isset($_FILES['logoFile'])) {
            $newLogoPath = handleFileUpload('logoFile', 'uploads');
            if ($newLogoPath) {
                // Delete old logo if exists
                if ($logoPath && file_exists(__DIR__ . '/../public/' . $logoPath)) {
                    unlink(__DIR__ . '/../public/' . $logoPath);
                }
                $logoPath = $newLogoPath;
            }
        }
        
        $stmt = $db->prepare("
            UPDATE markas 
            SET name = ?, description = ?, logo = ?, website = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");
        
        $stmt->execute([
            $name,
            $description,
            $logoPath,
            $website,
            $id
        ]);
        
        // Get the updated marka
        $stmt = $db->prepare("SELECT * FROM markas WHERE id = ?");
        $stmt->execute([$id]);
        $marka = $stmt->fetch();
        
        successResponse($marka, 'Marka yeniləndi');
        
    } catch (Exception $e) {
        errorResponse('Server xətası: ' . $e->getMessage(), 500);
    }
}

function deleteMarka($db, $id) {
    $user = authenticateToken();
    
    try {
        // Check if marka exists
        $stmt = $db->prepare("SELECT logo FROM markas WHERE id = ?");
        $stmt->execute([$id]);
        $marka = $stmt->fetch();
        
        if (!$marka) {
            errorResponse('Marka tapılmadı', 404);
        }
        
        // Check if marka is used by any products
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM products WHERE marka = (SELECT name FROM markas WHERE id = ?)");
        $stmt->execute([$id]);
        $productCount = $stmt->fetch()['count'];
        
        if ($productCount > 0) {
            errorResponse('Bu marka məhsullar tərəfindən istifadə olunur, silinə bilməz');
        }
        
        // Delete the marka
        $stmt = $db->prepare("DELETE FROM markas WHERE id = ?");
        $stmt->execute([$id]);
        
        // Delete associated logo file
        if ($marka['logo'] && file_exists(__DIR__ . '/../public/' . $marka['logo'])) {
            unlink(__DIR__ . '/../public/' . $marka['logo']);
        }
        
        successResponse([], 'Marka silindi');
        
    } catch (Exception $e) {
        errorResponse('Server xətası: ' . $e->getMessage(), 500);
    }
}
?>