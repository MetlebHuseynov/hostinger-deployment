<?php
/**
 * Users API Endpoints
 * CRUD əməliyyatları istifadəçilər üçün
 */

// Get user ID if provided
$userId = isset($pathParts[1]) && is_numeric($pathParts[1]) ? (int)$pathParts[1] : null;

switch ($method) {
    case 'GET':
        getUsers($db);
        break;
    case 'POST':
        createUser($db);
        break;
    case 'PUT':
        if ($userId) {
            updateUser($db, $userId);
        } else {
            errorResponse('İstifadəçi ID tələb olunur', 400);
        }
        break;
    case 'DELETE':
        if ($userId) {
            deleteUser($db, $userId);
        } else {
            errorResponse('İstifadəçi ID tələb olunur', 400);
        }
        break;
    default:
        errorResponse('Method dəstəklənmir', 405);
}

function getUsers($db) {
    $user = authenticateToken();
    
    // Only admin can view all users
    if ($user['role'] !== 'admin') {
        errorResponse('Bu əməliyyat üçün admin hüququ tələb olunur', 403);
    }
    
    try {
        $stmt = $db->prepare("SELECT id, username, email, role, created_at FROM users ORDER BY created_at DESC");
        $stmt->execute();
        $users = $stmt->fetchAll();
        
        successResponse($users);
        
    } catch (Exception $e) {
        errorResponse('Server xətası: ' . $e->getMessage(), 500);
    }
}

function createUser($db) {
    $currentUser = authenticateToken();
    
    // Only admin can create users
    if ($currentUser['role'] !== 'admin') {
        errorResponse('Bu əməliyyat üçün admin hüququ tələb olunur', 403);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $username = $input['username'] ?? null;
    $email = $input['email'] ?? null;
    $password = $input['password'] ?? null;
    $role = $input['role'] ?? 'user';
    
    if (!$username || !$email || !$password) {
        errorResponse('İstifadəçi adı, email və parol tələb olunur');
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        errorResponse('Etibarsız email formatı');
    }
    
    if (strlen($password) < 6) {
        errorResponse('Parol ən azı 6 simvol olmalıdır');
    }
    
    if (!in_array($role, ['admin', 'user'])) {
        errorResponse('Etibarsız rol');
    }
    
    try {
        // Check if username already exists
        $stmt = $db->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            errorResponse('Bu istifadəçi adı artıq mövcuddur');
        }
        
        // Check if email already exists
        $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            errorResponse('Bu email artıq mövcuddur');
        }
        
        // Hash password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt = $db->prepare("
            INSERT INTO users (username, email, password, role) 
            VALUES (?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $username,
            $email,
            $hashedPassword,
            $role
        ]);
        
        $userId = $db->lastInsertId();
        
        // Get the created user (without password)
        $stmt = $db->prepare("SELECT id, username, email, role, created_at FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        
        successResponse($user, 'İstifadəçi yaradıldı');
        
    } catch (Exception $e) {
        errorResponse('Server xətası: ' . $e->getMessage(), 500);
    }
}

function updateUser($db, $id) {
    $currentUser = authenticateToken();
    
    // Only admin can update users, or user can update themselves
    if ($currentUser['role'] !== 'admin' && $currentUser['id'] != $id) {
        errorResponse('Bu əməliyyat üçün admin hüququ tələb olunur', 403);
    }
    
    $input = json_decode(file_get_contents('php://input'), true);
    
    $username = $input['username'] ?? null;
    $email = $input['email'] ?? null;
    $password = $input['password'] ?? null;
    $role = $input['role'] ?? null;
    
    if (!$username || !$email) {
        errorResponse('İstifadəçi adı və email tələb olunur');
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        errorResponse('Etibarsız email formatı');
    }
    
    // Only admin can change roles
    if ($role && $currentUser['role'] !== 'admin') {
        errorResponse('Rol dəyişdirmək üçün admin hüququ tələb olunur', 403);
    }
    
    if ($role && !in_array($role, ['admin', 'user'])) {
        errorResponse('Etibarsız rol');
    }
    
    try {
        // Check if user exists
        $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$id]);
        $existingUser = $stmt->fetch();
        
        if (!$existingUser) {
            errorResponse('İstifadəçi tapılmadı', 404);
        }
        
        // Check if username is already taken by another user
        $stmt = $db->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
        $stmt->execute([$username, $id]);
        if ($stmt->fetch()) {
            errorResponse('Bu istifadəçi adı artıq mövcuddur');
        }
        
        // Check if email is already taken by another user
        $stmt = $db->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $stmt->execute([$email, $id]);
        if ($stmt->fetch()) {
            errorResponse('Bu email artıq mövcuddur');
        }
        
        // Prepare update query
        $updateFields = ['username = ?', 'email = ?'];
        $params = [$username, $email];
        
        // Add password if provided
        if ($password) {
            if (strlen($password) < 6) {
                errorResponse('Parol ən azı 6 simvol olmalıdır');
            }
            $updateFields[] = 'password = ?';
            $params[] = password_hash($password, PASSWORD_DEFAULT);
        }
        
        // Add role if provided and user is admin
        if ($role && $currentUser['role'] === 'admin') {
            $updateFields[] = 'role = ?';
            $params[] = $role;
        }
        
        $updateFields[] = 'updated_at = CURRENT_TIMESTAMP';
        $params[] = $id;
        
        $sql = "UPDATE users SET " . implode(', ', $updateFields) . " WHERE id = ?";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        
        // Get the updated user (without password)
        $stmt = $db->prepare("SELECT id, username, email, role, created_at, updated_at FROM users WHERE id = ?");
        $stmt->execute([$id]);
        $user = $stmt->fetch();
        
        successResponse($user, 'İstifadəçi yeniləndi');
        
    } catch (Exception $e) {
        errorResponse('Server xətası: ' . $e->getMessage(), 500);
    }
}

function deleteUser($db, $id) {
    $currentUser = authenticateToken();
    
    // Only admin can delete users
    if ($currentUser['role'] !== 'admin') {
        errorResponse('Bu əməliyyat üçün admin hüququ tələb olunur', 403);
    }
    
    // Prevent admin from deleting themselves
    if ($currentUser['id'] == $id) {
        errorResponse('Özünüzü silə bilməzsiniz');
    }
    
    try {
        // Check if user exists
        $stmt = $db->prepare("SELECT id FROM users WHERE id = ?");
        $stmt->execute([$id]);
        $user = $stmt->fetch();
        
        if (!$user) {
            errorResponse('İstifadəçi tapılmadı', 404);
        }
        
        // Delete the user
        $stmt = $db->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$id]);
        
        successResponse([], 'İstifadəçi silindi');
        
    } catch (Exception $e) {
        errorResponse('Server xətası: ' . $e->getMessage(), 500);
    }
}
?>