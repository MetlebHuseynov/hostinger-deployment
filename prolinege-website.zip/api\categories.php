<?php
/**
 * Categories API Endpoints
 * CRUD əməliyyatları kateqoriyalar üçün
 */

// Get category ID if provided
$categoryId = isset($pathParts[1]) && is_numeric($pathParts[1]) ? (int)$pathParts[1] : null;

switch ($method) {
    case 'GET':
        if ($categoryId) {
            getCategory($db, $categoryId);
        } else {
            getCategories($db);
        }
        break;
    case 'POST':
        createCategory($db);
        break;
    case 'PUT':
        if ($categoryId) {
            updateCategory($db, $categoryId);
        } else {
            errorResponse('Kateqoriya ID tələb olunur', 400);
        }
        break;
    case 'DELETE':
        if ($categoryId) {
            deleteCategory($db, $categoryId);
        } else {
            errorResponse('Kateqoriya ID tələb olunur', 400);
        }
        break;
    default:
        errorResponse('Method dəstəklənmir', 405);
}

function getCategories($db) {
    try {
        $stmt = $db->prepare("SELECT * FROM categories ORDER BY name ASC");
        $stmt->execute();
        $categories = $stmt->fetchAll();
        
        successResponse($categories);
        
    } catch (Exception $e) {
        errorResponse('Server xətası: ' . $e->getMessage(), 500);
    }
}

function getCategory($db, $id) {
    try {
        $stmt = $db->prepare("SELECT * FROM categories WHERE id = ?");
        $stmt->execute([$id]);
        $category = $stmt->fetch();
        
        if (!$category) {
            errorResponse('Kateqoriya tapılmadı', 404);
        }
        
        successResponse($category);
        
    } catch (Exception $e) {
        errorResponse('Server xətası: ' . $e->getMessage(), 500);
    }
}

function createCategory($db) {
    $user = authenticateToken();
    
    $name = $_POST['name'] ?? null;
    $description = $_POST['description'] ?? null;
    
    if (!$name) {
        errorResponse('Kateqoriya adı tələb olunur');
    }
    
    // Handle file upload
    $imagePath = null;
    if (isset($_FILES['imageFile'])) {
        $imagePath = handleFileUpload('imageFile', 'uploads');
    }
    
    try {
        // Check if category already exists
        $stmt = $db->prepare("SELECT id FROM categories WHERE name = ?");
        $stmt->execute([$name]);
        if ($stmt->fetch()) {
            errorResponse('Bu adda kateqoriya artıq mövcuddur');
        }
        
        $stmt = $db->prepare("
            INSERT INTO categories (name, description, image) 
            VALUES (?, ?, ?)
        ");
        
        $stmt->execute([
            $name,
            $description,
            $imagePath
        ]);
        
        $categoryId = $db->lastInsertId();
        
        // Get the created category
        $stmt = $db->prepare("SELECT * FROM categories WHERE id = ?");
        $stmt->execute([$categoryId]);
        $category = $stmt->fetch();
        
        successResponse($category, 'Kateqoriya yaradıldı');
        
    } catch (Exception $e) {
        errorResponse('Server xətası: ' . $e->getMessage(), 500);
    }
}

function updateCategory($db, $id) {
    $user = authenticateToken();
    
    $name = $_POST['name'] ?? null;
    $description = $_POST['description'] ?? null;
    
    if (!$name) {
        errorResponse('Kateqoriya adı tələb olunur');
    }
    
    try {
        // Check if category exists
        $stmt = $db->prepare("SELECT * FROM categories WHERE id = ?");
        $stmt->execute([$id]);
        $existingCategory = $stmt->fetch();
        
        if (!$existingCategory) {
            errorResponse('Kateqoriya tapılmadı', 404);
        }
        
        // Check if name is already taken by another category
        $stmt = $db->prepare("SELECT id FROM categories WHERE name = ? AND id != ?");
        $stmt->execute([$name, $id]);
        if ($stmt->fetch()) {
            errorResponse('Bu adda kateqoriya artıq mövcuddur');
        }
        
        // Handle file upload
        $imagePath = $existingCategory['image'];
        if (isset($_FILES['imageFile'])) {
            $newImagePath = handleFileUpload('imageFile', 'uploads');
            if ($newImagePath) {
                // Delete old image if exists
                if ($imagePath && file_exists(__DIR__ . '/../public/' . $imagePath)) {
                    unlink(__DIR__ . '/../public/' . $imagePath);
                }
                $imagePath = $newImagePath;
            }
        }
        
        $stmt = $db->prepare("
            UPDATE categories 
            SET name = ?, description = ?, image = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");
        
        $stmt->execute([
            $name,
            $description,
            $imagePath,
            $id
        ]);
        
        // Get the updated category
        $stmt = $db->prepare("SELECT * FROM categories WHERE id = ?");
        $stmt->execute([$id]);
        $category = $stmt->fetch();
        
        successResponse($category, 'Kateqoriya yeniləndi');
        
    } catch (Exception $e) {
        errorResponse('Server xətası: ' . $e->getMessage(), 500);
    }
}

function deleteCategory($db, $id) {
    $user = authenticateToken();
    
    try {
        // Check if category exists
        $stmt = $db->prepare("SELECT image FROM categories WHERE id = ?");
        $stmt->execute([$id]);
        $category = $stmt->fetch();
        
        if (!$category) {
            errorResponse('Kateqoriya tapılmadı', 404);
        }
        
        // Check if category is used by any products
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM products WHERE category = (SELECT name FROM categories WHERE id = ?)");
        $stmt->execute([$id]);
        $productCount = $stmt->fetch()['count'];
        
        if ($productCount > 0) {
            errorResponse('Bu kateqoriya məhsullar tərəfindən istifadə olunur, silinə bilməz');
        }
        
        // Delete the category
        $stmt = $db->prepare("DELETE FROM categories WHERE id = ?");
        $stmt->execute([$id]);
        
        // Delete associated image file
        if ($category['image'] && file_exists(__DIR__ . '/../public/' . $category['image'])) {
            unlink(__DIR__ . '/../public/' . $category['image']);
        }
        
        successResponse([], 'Kateqoriya silindi');
        
    } catch (Exception $e) {
        errorResponse('Server xətası: ' . $e->getMessage(), 500);
    }
}
?>