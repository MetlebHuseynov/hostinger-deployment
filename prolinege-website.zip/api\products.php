<?php
/**
 * Products API Endpoints
 * CRUD əməliyyatları məhsullar üçün
 */

// Get product ID if provided
$productId = isset($pathParts[1]) && is_numeric($pathParts[1]) ? (int)$pathParts[1] : null;

switch ($method) {
    case 'GET':
        if ($productId) {
            getProduct($db, $productId);
        } else {
            getProducts($db);
        }
        break;
    case 'POST':
        createProduct($db);
        break;
    case 'PUT':
        if ($productId) {
            updateProduct($db, $productId);
        } else {
            errorResponse('Məhsul ID tələb olunur', 400);
        }
        break;
    case 'DELETE':
        if ($productId) {
            deleteProduct($db, $productId);
        } else {
            errorResponse('Məhsul ID tələb olunur', 400);
        }
        break;
    default:
        errorResponse('Method dəstəklənmir', 405);
}

function getProducts($db) {
    try {
        $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
        $limit = isset($_GET['limit']) ? min(100, max(1, (int)$_GET['limit'])) : 10;
        $offset = ($page - 1) * $limit;
        
        $category = $_GET['category'] ?? null;
        $marka = $_GET['marka'] ?? null;
        $search = $_GET['search'] ?? null;
        
        // Build query
        $whereConditions = [];
        $params = [];
        
        if ($category) {
            $whereConditions[] = "category = ?";
            $params[] = $category;
        }
        
        if ($marka) {
            $whereConditions[] = "marka = ?";
            $params[] = $marka;
        }
        
        if ($search) {
            $whereConditions[] = "(name LIKE ? OR description LIKE ?)";
            $params[] = "%$search%";
            $params[] = "%$search%";
        }
        
        $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
        
        // Get total count
        $countSql = "SELECT COUNT(*) as total FROM products $whereClause";
        $countStmt = $db->prepare($countSql);
        $countStmt->execute($params);
        $total = $countStmt->fetch()['total'];
        
        // Get products
        $sql = "SELECT * FROM products $whereClause ORDER BY created_at DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $products = $stmt->fetchAll();
        
        successResponse([
            'products' => $products,
            'pagination' => [
                'page' => $page,
                'limit' => $limit,
                'total' => (int)$total,
                'pages' => ceil($total / $limit)
            ]
        ]);
        
    } catch (Exception $e) {
        errorResponse('Server xətası: ' . $e->getMessage(), 500);
    }
}

function getProduct($db, $id) {
    try {
        $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$id]);
        $product = $stmt->fetch();
        
        if (!$product) {
            errorResponse('Məhsul tapılmadı', 404);
        }
        
        successResponse($product);
        
    } catch (Exception $e) {
        errorResponse('Server xətası: ' . $e->getMessage(), 500);
    }
}

function createProduct($db) {
    $user = authenticateToken();
    
    $name = $_POST['name'] ?? null;
    $description = $_POST['description'] ?? null;
    $price = $_POST['price'] ?? null;
    $category = $_POST['category'] ?? null;
    $marka = $_POST['marka'] ?? null;
    
    if (!$name || !$price) {
        errorResponse('Məhsul adı və qiymət tələb olunur');
    }
    
    // Handle file upload
    $imagePath = null;
    if (isset($_FILES['imageFile'])) {
        $imagePath = handleFileUpload('imageFile', 'uploads');
    }
    
    try {
        $stmt = $db->prepare("
            INSERT INTO products (name, description, price, category, marka, image) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $name,
            $description,
            (float)$price,
            $category,
            $marka,
            $imagePath
        ]);
        
        $productId = $db->lastInsertId();
        
        // Get the created product
        $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$productId]);
        $product = $stmt->fetch();
        
        successResponse($product, 'Məhsul yaradıldı');
        
    } catch (Exception $e) {
        errorResponse('Server xətası: ' . $e->getMessage(), 500);
    }
}

function updateProduct($db, $id) {
    $user = authenticateToken();
    
    $name = $_POST['name'] ?? null;
    $description = $_POST['description'] ?? null;
    $price = $_POST['price'] ?? null;
    $category = $_POST['category'] ?? null;
    $marka = $_POST['marka'] ?? null;
    
    if (!$name || !$price) {
        errorResponse('Məhsul adı və qiymət tələb olunur');
    }
    
    try {
        // Check if product exists
        $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$id]);
        $existingProduct = $stmt->fetch();
        
        if (!$existingProduct) {
            errorResponse('Məhsul tapılmadı', 404);
        }
        
        // Handle file upload
        $imagePath = $existingProduct['image'];
        if (isset($_FILES['imageFile'])) {
            $newImagePath = handleFileUpload('imageFile', 'uploads');
            if ($newImagePath) {
                // Delete old image if exists
                if ($imagePath && file_exists(__DIR__ . '/../public/' . $imagePath)) {
                    unlink(__DIR__ . '/../public/' . $imagePath);
                }
                $imagePath = $newImagePath;
            }
        }
        
        $stmt = $db->prepare("
            UPDATE products 
            SET name = ?, description = ?, price = ?, category = ?, marka = ?, image = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");
        
        $stmt->execute([
            $name,
            $description,
            (float)$price,
            $category,
            $marka,
            $imagePath,
            $id
        ]);
        
        // Get the updated product
        $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$id]);
        $product = $stmt->fetch();
        
        successResponse($product, 'Məhsul yeniləndi');
        
    } catch (Exception $e) {
        errorResponse('Server xətası: ' . $e->getMessage(), 500);
    }
}

function deleteProduct($db, $id) {
    $user = authenticateToken();
    
    try {
        // Check if product exists
        $stmt = $db->prepare("SELECT image FROM products WHERE id = ?");
        $stmt->execute([$id]);
        $product = $stmt->fetch();
        
        if (!$product) {
            errorResponse('Məhsul tapılmadı', 404);
        }
        
        // Delete the product
        $stmt = $db->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$id]);
        
        // Delete associated image file
        if ($product['image'] && file_exists(__DIR__ . '/../public/' . $product['image'])) {
            unlink(__DIR__ . '/../public/' . $product['image']);
        }
        
        successResponse([], 'Məhsul silindi');
        
    } catch (Exception $e) {
        errorResponse('Server xətası: ' . $e->getMessage(), 500);
    }
}
?>