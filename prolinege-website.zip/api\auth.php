<?php
/**
 * Authentication API Endpoints
 * Login və user authentication
 */

// Handle different auth endpoints
if (count($pathParts) > 1) {
    $authAction = $pathParts[1];
} else {
    $authAction = '';
}

switch ($method) {
    case 'POST':
        if ($authAction === 'login') {
            handleLogin($db);
        } else {
            errorResponse('Auth endpoint tapılmadı', 404);
        }
        break;
    case 'GET':
        if ($authAction === 'me') {
            handleGetMe($db);
        } else {
            errorResponse('Auth endpoint tapılmadı', 404);
        }
        break;
    default:
        errorResponse('Method dəstəklənmir', 405);
}

function handleLogin($db) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['username']) || !isset($input['password'])) {
        errorResponse('İstifadəçi adı və parol tələb olunur');
    }
    
    $username = $input['username'];
    $password = $input['password'];
    
    try {
        // Check if user exists
        $stmt = $db->prepare("SELECT id, username, email, password, role FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch();
        
        if (!$user) {
            errorResponse('İstifadəçi tapılmadı', 401);
        }
        
        // Verify password
        if (!password_verify($password, $user['password'])) {
            errorResponse('Yanlış parol', 401);
        }
        
        // Create JWT token
        $payload = [
            'id' => $user['id'],
            'username' => $user['username'],
            'email' => $user['email'],
            'role' => $user['role'],
            'iat' => time(),
            'exp' => time() + (24 * 60 * 60) // 24 hours
        ];
        
        $token = JWT::encode($payload);
        
        successResponse([
            'token' => $token,
            'user' => [
                'id' => $user['id'],
                'username' => $user['username'],
                'email' => $user['email'],
                'role' => $user['role']
            ]
        ], 'Giriş uğurlu');
        
    } catch (Exception $e) {
        errorResponse('Server xətası: ' . $e->getMessage(), 500);
    }
}

function handleGetMe($db) {
    $user = authenticateToken();
    
    try {
        // Get fresh user data from database
        $stmt = $db->prepare("SELECT id, username, email, role, created_at FROM users WHERE id = ?");
        $stmt->execute([$user['id']]);
        $userData = $stmt->fetch();
        
        if (!$userData) {
            errorResponse('İstifadəçi tapılmadı', 404);
        }
        
        successResponse($userData);
        
    } catch (Exception $e) {
        errorResponse('Server xətası: ' . $e->getMessage(), 500);
    }
}
?>